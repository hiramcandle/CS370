%
%    Demonstration of pursuit problem
%

global DMIN SP

METHOD = 1;
y0     = [0;0;-3];
SP     = 1.5;
DMIN   = 0.1;

t0 = 0; tfinal = 20;

options=odeset('AbsTol',1e-10,'RelTol',1e-5,'InitialStep',10,'MaxStep',10);

options=odeset(options,'Refine',4,'events','on');

if METHOD == 1
  [t,y] = ode23('rocket',[t0,tfinal],y0,options);
else
  [t,y] = ode45('rocket',[t0,tfinal],y0,options);
end;

%
% Plot the trajectory of the pursuer and target
%
animate(t,y);

