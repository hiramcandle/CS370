function [dP,halt,direction] = rocket(t,P,flag)
%
% This is the function that is called by the ode solver.
% It implements the differential equations defining the
% trajectory of the pursuer.
%
%
% When the rocket gets within DMIN of the
% target, it records the time t at which this happens.

global DMIN SP

T = target(t);
dx = T-P;
d = norm(dx,2);

if nargin<3 | isempty(flag)
  dP = SP/d*dx;
elseif strcmp(flag,'events')
  dP=d-DMIN;
  halt=1;
  direction=0;
end;
