function animate(t,P)


%
% Plot the trajectory of the pursuer and target.
%
% t is the vector of times
% P is the vector of (3d) points
%
figure(1); clf;
n = length(t);

xmin=min(P(:,1)); xmax=max(P(:,1));
ymin=min(P(:,2)); ymax=max(P(:,2));
zmin=min(P(:,3)); zmax=max(P(:,3));

% make minimums and maximums just a bit bigger - looks better

xmin=xmin-0.1*(xmax-xmin); xmax=xmax+0.1*(xmax-xmin);
ymin=ymin-0.1*(ymax-ymin); ymax=ymax+0.1*(ymax-ymin);
zmin=zmin-0.1*(zmax-zmin); zmax=zmax+0.1*(zmax-zmin);

if zmax==zmin, zmin=-1; zmax=1; end;

% get 3d set of points for the target at the first time

T=target(t(1));

% plot the first points of both the target and the pursuer

TH = plot3(T(1),T(2),T(3),'bx','linewidth',2,'markersize',12); hold on;
PH = plot3(P(1,1),P(1,2),P(1,3),'ro','linewidth',2,'markersize',9);


set(TH,'erasemode','none');
set(PH,'erasemode','none');
view(-37.5,20);
axis([xmin xmax ymin ymax zmin zmax]);

Tx=[]; Ty=[]; Tz=[];
Px=[]; Py=[]; Pz=[];

% let the chase begin

for s = 1:n
  T = target(t(s));

  Tx=T(1); Ty=T(2); Tz=T(3);
  Px=P(s,1); Py=P(s,2); Pz=P(s,3);
  set(TH,'xdata',Tx,'ydata',Ty,'zdata',Tz);
  set(PH,'xdata',Px,'ydata',Py,'zdata',Pz);
  drawnow;
  pause(0.03);
end 
