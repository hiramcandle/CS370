function T = target(t)
%
% This is the target function for the pursuit
% problem. It models the system
%  
%  x'(t) = sin(t) 
%  y'(t) = cos(t) 
%  z'(t) = t
%
%

    T = zeros(3,1);
    T(1) = sin(t); 
    T(2) = cos(t);
    T(3) = t;   
end

